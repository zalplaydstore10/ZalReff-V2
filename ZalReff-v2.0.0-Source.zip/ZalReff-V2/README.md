# ZalReff

**ZalReff V2.0.0** adalah plugin referral untuk server Minecraft berbasis Paper.

## Informasi proyek

| Item | Detail |
|---|---|
| Nama | ZalReff |
| Versi | 2.0.0 |
| Author | ZALPLAYD |
| Java | 17 |
| Build | Maven |
| Target server | Paper 1.20.1–1.21.5 (kompatibilitas perlu diuji pada tiap versi) |
| Economy | Vault API |
| Repository | https://github.com/zalplaydstore10/ZalReff-V2 |

## Fitur yang tersedia di source

- Kode referral yang didefinisikan di `config.yml`.
- GUI referral melalui `/reff` atau `/reff menu`.
- Satu UUID pemain hanya dapat tercatat satu kali.
- Pelacakan waktu aktif referral sampai 60 menit secara default.
- Reward uang melalui Vault jika Vault dan provider ekonomi tersedia.
- Reward untuk pemilik kode/streamer saat claim dan saat referral menjadi valid.
- Pembatasan claim berbasis permission, sehingga dapat dikelola melalui LuckPerms.
- Data referral disimpan di `plugins/ZalReff/data.yml`.

> Catatan: daftar di atas menjelaskan implementasi yang ada di source. Tetap lakukan pengujian di server Paper target sebelum dipakai di server utama.

## Aturan rank

Secara default, hanya pemain yang memiliki permission `zalreff.blockclaim.streamer` yang diblokir dari claim referral. Rank lain—termasuk Member, Default+, VIP, MVP, Admin, OP, dan rank custom—tidak diblokir oleh plugin selama permission tersebut tidak diberikan kepada mereka.

Contoh LuckPerms untuk grup Streamer:

```text
/lp group streamer permission set zalreff.blockclaim.streamer true
```

Jangan berikan permission tersebut kepada grup lain jika hanya rank Streamer yang harus diblokir.

## Dependensi

- Paper server.
- Java 17.
- Vault.
- Plugin ekonomi yang menyediakan layanan Vault (misalnya EssentialsX Economy).

LuckPerms tidak wajib menjadi dependensi compile-time; pembatasan rank menggunakan permission Bukkit yang dapat dikelola LuckPerms.

## Perintah

| Perintah | Fungsi |
|---|---|
| `/reff` | Membuka GUI |
| `/reff menu` | Membuka GUI |
| `/reff <kode>` | Claim kode referral |
| `/reff top` | Melihat leaderboard mingguan |
| `/reff cek <player>` | Memeriksa status referral (admin) |
| `/reff reload` | Memuat ulang konfigurasi (admin) |

Permission admin: `zalreff.admin` (default OP).

## Konfigurasi

Edit `src/main/resources/config.yml` sebelum build atau `plugins/ZalReff/config.yml` setelah plugin pertama kali dijalankan.

- `settings.required-playtime-minutes`: durasi validasi, default 60 menit.
- `settings.afk-timeout-seconds`: batas idle sebelum waktu aktif dihentikan.
- `economy.rewards`: nominal reward.
- `referral-codes`: daftar kode dan nama akun streamer penerima bonus.
- `restrictions.block-claim-permissions`: permission yang memblokir claim.

## Build lokal

Pastikan Java 17 dan Maven tersedia, lalu jalankan dari folder yang berisi `pom.xml`:

```bash
mvn --batch-mode clean package
```

Hasil JAR:

```text
target/ZalReff-V2.jar
```

## GitHub Actions

Workflow ada di `.github/workflows/build.yml`. Workflow mendukung dua susunan repository:

1. Source project diekstrak langsung sehingga `pom.xml` berada di root repository; atau
2. Satu ZIP source berada di root repository, lalu workflow mengekstraknya otomatis.

Hasil build diunggah sebagai artifact bernama `ZalReff-V2-JAR`.

## Instalasi

1. Pastikan Paper dan Java 17 berjalan.
2. Pasang Vault dan plugin ekonomi yang kompatibel.
3. Salin `ZalReff-V2.jar` ke folder `plugins`.
4. Restart server.
5. Atur kode referral, reward, dan permission Streamer di `config.yml`.
6. Uji dengan akun percobaan sebelum digunakan pemain.

## Status verifikasi

Source ini sudah ditata ulang dan workflow build diperbaiki agar tidak bergantung pada satu nama ZIP tertentu. Build Maven belum dinyatakan lulus dalam lingkungan pembuatan arsip ini; status final harus ditentukan dari hasil GitHub Actions atau build Maven lokal.
