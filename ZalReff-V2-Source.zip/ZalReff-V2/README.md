# ZalReff V2
Universal referral GUI and rewards plugin for Paper/Spigot 1.20.1+. Java 17.

## Build
`mvn clean package` -> `target/ZalReff-V2.jar`

## Economy
Vault is an optional integration. Install Vault plus any Vault-compatible economy provider (for example EssentialsX Economy or CMI economy). Without Vault/provider, referral tracking and GUI still work; money rewards are skipped.

## Referral configuration
Edit `referral-codes` in config.yml. Each code may define a `streamer` account name. Configure `economy.rewards` for immediate claim rewards and valid-after-playtime rewards.

## Commands
`/reff` or `/reff menu` opens GUI; `/reff <code>` claims directly; `/reff top` weekly leaderboard; `/reff cek <player>` and `/reff reload` are admin commands.

Permission: `zalreff.admin`. Data is stored in `plugins/ZalReff/data.yml`. The plugin stores its own data in `plugins/ZalReff/data.yml`.
