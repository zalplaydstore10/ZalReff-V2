package com.zalplayd.zalreff;

import com.zalplayd.zalreff.commands.ReffCommand;
import com.zalplayd.zalreff.listeners.PlaytimeListener;
import com.zalplayd.zalreff.managers.DataManager;
import com.zalplayd.zalreff.managers.MessageManager;
import com.zalplayd.zalreff.managers.EconomyManager;
import com.zalplayd.zalreff.gui.ReffMenuListener;
import org.bukkit.entity.Player;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class ZalReff extends JavaPlugin {
    private DataManager dataManager;
    private MessageManager messageManager;
    private EconomyManager economyManager;
    private ReffMenuListener menuListener;

    @Override public void onEnable() {
        saveDefaultConfig();
        this.messageManager = new MessageManager(this);
        this.dataManager = new DataManager(this);
        this.economyManager = new EconomyManager(this);
        this.menuListener = new ReffMenuListener(this);
        Bukkit.getPluginManager().registerEvents(menuListener, this);
        ReffCommand command = new ReffCommand(this);
        getCommand("reff").setExecutor(command);
        getCommand("reff").setTabCompleter(command);
        Bukkit.getPluginManager().registerEvents(new PlaytimeListener(this), this);
        long minutes = Math.max(1L, getConfig().getLong("settings.auto-save-minutes", 5));
        Bukkit.getScheduler().runTaskTimer(this, dataManager::save, minutes * 60L * 20L, minutes * 60L * 20L);
        getLogger().info("ZalReff V2 enabled. Vault economy: " + economyManager.available());
    }

    @Override public void onDisable() { if (dataManager != null) dataManager.save(); }
    public void reloadPlugin() {
        reloadConfig(); messageManager.reload(); dataManager.reloadSettings(); economyManager.setup();
    }
    public DataManager data() { return dataManager; }
    public MessageManager messages() { return messageManager; }
    public EconomyManager economy() { return economyManager; }
    public void openMenu(Player player) { menuListener.open(player); }
    public void claimReferral(Player player, String code) {
        // Rank restrictions are permission-based so the plugin works with LuckPerms
        // and other permission managers without requiring a specific rank plugin.
        for (String permission : getConfig().getStringList("restrictions.block-claim-permissions")) {
            if (permission != null && !permission.isBlank() && player.hasPermission(permission)) {
                messages().send(player, "reff-rank-blocked");
                return;
            }
        }
        if (dataManager.get(player.getUniqueId()) != null) { messages().send(player, "reff-already", Map.of("kode_lama", dataManager.get(player.getUniqueId()).code)); return; }
        String match = dataManager.getCodes().stream().filter(c -> c.equalsIgnoreCase(code)).findFirst().orElse(null);
        if (match == null) { messages().send(player, "reff-not-found", Map.of("kode", code)); return; }
        String streamer = getConfig().getString("referral-codes." + match + ".streamer", "");
        if (streamer != null && !streamer.isBlank() && streamer.equalsIgnoreCase(player.getName())) {
            messages().send(player, "reff-self-claim", Map.of("kode", match));
            return;
        }
        if (!dataManager.claim(player.getUniqueId(), player.getName(), match)) return;
        economyManager.pay(player, economyManager.reward("player-on-claim"), "referral claim");
        economyManager.payStreamer(streamer, economyManager.reward("streamer-on-join"), "referral join");
        messages().send(player, "reff-success", Map.of("kode", match));
    }
}
