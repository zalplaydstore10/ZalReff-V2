package com.zalplayd.zalreff.managers;

import com.zalplayd.zalreff.ZalReff;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import java.util.Map;

public class MessageManager {
    private final ZalReff plugin;
    public MessageManager(ZalReff plugin) { this.plugin = plugin; }
    public void reload() { }
    public String get(String key, Map<String, String> placeholders) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        String message = plugin.getConfig().getString("messages." + key, "&cMissing message: " + key);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) message = message.replace("%" + entry.getKey() + "%", entry.getValue());
        return ChatColor.translateAlternateColorCodes('&', prefix + message);
    }
    public String get(String key) { return get(key, Map.of()); }
    public void send(CommandSender sender, String key, Map<String, String> placeholders) { sender.sendMessage(get(key, placeholders)); }
    public void send(CommandSender sender, String key) { send(sender, key, Map.of()); }
}
