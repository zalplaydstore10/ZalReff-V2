package com.zalplayd.zalreff.gui;

import com.zalplayd.zalreff.ZalReff;
import org.bukkit.Bukkit; import org.bukkit.ChatColor; import org.bukkit.Material; import org.bukkit.entity.Player; import org.bukkit.event.*; import org.bukkit.event.inventory.InventoryClickEvent; import org.bukkit.inventory.*; import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;

public final class ReffMenuListener implements Listener {
 private final ZalReff plugin; public ReffMenuListener(ZalReff p){plugin=p;}
 public void open(Player p){ Inventory inv=Bukkit.createInventory(null,54,color(plugin.getConfig().getString("settings.gui-title","&0ZalReff"))); ItemStack filler=item(Material.GRAY_STAINED_GLASS_PANE," ",List.of()); for(int i=0;i<54;i++)inv.setItem(i,filler);
  int slot=10; for(String code:plugin.data().getCodes()){ if(slot>=44)break; if(slot%9==8)slot+=2; ItemStack it=item(Material.NAME_TAG,"&b&l"+code,List.of("&7Klik untuk menggunakan kode ini","&eReward saat klaim: "+plugin.getConfig().getDouble("economy.rewards.player-on-claim",0),"&7Bonus setelah 60 menit aktif")); inv.setItem(slot++,it); }
  inv.setItem(49,item(Material.BOOK,"&eInformasi Referral",List.of("&7Klaim hanya dapat dilakukan sekali.","&7Waktu AFK tidak dihitung.","&7Gunakan &f/reff top &7untuk leaderboard."))); p.openInventory(inv);
 }
 private ItemStack item(Material m,String name,List<String> lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();meta.setDisplayName(color(name));meta.setLore(lore.stream().map(this::color).toList());i.setItemMeta(meta);return i;}
 private String color(String s){return ChatColor.translateAlternateColorCodes('&',s);}
 @EventHandler public void click(InventoryClickEvent e){ if(!(e.getWhoClicked() instanceof Player p))return; if(!ChatColor.stripColor(e.getView().getTitle()).startsWith("ZalReff"))return; e.setCancelled(true); ItemStack it=e.getCurrentItem(); if(it==null||!it.hasItemMeta()||!it.getItemMeta().hasDisplayName())return; String code=ChatColor.stripColor(it.getItemMeta().getDisplayName()); if(!plugin.data().getCodes().stream().anyMatch(c->c.equalsIgnoreCase(code)))return; plugin.claimReferral(p,code); p.closeInventory(); }
}
